# HCI & Design Research Guide

For a researcher working at the intersection of HCI, Embodied Interaction, Human-Robot Interaction, and AI + Design.

Reference this during Stage 4 (Mechanism Reasoning) and Stage 5 (Reality Mapping) when the text involves interaction research, design methodology, or systems involving humans and technology.

---

## CORE THEORETICAL FRAMEWORKS IN THIS RESEARCHER'S FIELD

### Embodied Cognition (Merleau-Ponty → Dreyfus → Dourish)
- Knowing is not separate from doing — the body is primary, not the mind
- Skills are absorbed into the body, not represented symbolically
- Key claim: interface design should work *with* the body, not route around it
- Design implication: tangible interaction, gestural control, physical feedback
- Tension: embodiment theory vs. information-processing models of the mind

### Affordance Theory (Gibson → Norman)
- Affordance: the action possibilities a system offers a user
- Gibson: affordances are real properties in the world
- Norman: affordances are perceived — design creates perceived affordance
- Key distinction: designed affordance vs. perceived affordance vs. actual affordance
- Design implication: if users don't perceive the affordance, it doesn't exist for them

### Activity Theory (Vygotsky → Leont'ev → Engeström)
- Human activity is mediated by tools, and tools shape the activity
- Three levels: Activity (motive) → Action (goal) → Operation (automated habit)
- Key claim: you cannot understand use without understanding the whole activity system
- HCI implication: don't design for isolated tasks — design for the whole context of work or life

### Distributed Cognition (Hutchins)
- Cognition is not inside the head — it is distributed across people, artifacts, and environment
- Example: navigation of a ship is distributed across crew, instruments, maps, and procedures
- Design implication: the system is not just the software — it includes everything the user does

### Situated Action (Suchman)
- Behavior is not plan-execution — it is improvised in response to the actual situation
- Critique of AI planning models: plans are resources for action, not scripts
- HCI implication: systems that assume users follow plans will fail; design for adaptation

### Values in Design / Value-Sensitive Design (Flanagan, Nissenbaum)
- Technologies embed values — this is not neutral
- Design decisions privilege some values and suppress others
- AI + design specific: whose values does the algorithm optimize for?

---

## MECHANISM ANALYSIS FOR HCI

When analyzing an interaction mechanism, use this lens:

### Interaction Flow Analysis
```
Trigger → Perception → Decision → Action → System Response → Feedback → Learning/Adaptation
```
At each step ask:
- What does the user need to know at this point?
- What does the system do here?
- Where can this break down?

### Cognitive Walkthrough Questions
For any design or system described in the text:
1. Will the user know what to do at each step?
2. Will the user see how to do it?
3. Will the user know if they did it correctly?
4. Can the user recover if they make an error?

### Mental Model Gap Analysis
- What mental model does the user bring to the interaction?
- What model does the designer assume the user has?
- What model does the system actually require?
- Gap = friction, confusion, error

---

## OBSERVATION PROTOCOL FOR INTERACTION RESEARCH

When the text involves user studies, field research, or interaction observation:

### What to watch for
1. What does the user try to do before they know how the system works?
2. Where does the user pause, hesitate, or look confused?
3. What workarounds do users invent that were not designed?
4. What does the user say vs. what do they actually do? (self-report vs. behavior gap)
5. What gets easier with practice, and what doesn't?
6. What does the user's body do? (posture, gaze, gesture, distance to device)
7. How does social context change the interaction? (alone vs. observed, collocated vs. remote)
8. What happens at transition points? (starting, stopping, switching tasks, errors)

### Research Method Map
| Method | Best for | Limitation |
|--------|----------|------------|
| Think-aloud protocol | Revealing mental model in real time | Changes behavior by making it conscious |
| Video analysis | Body, gesture, gaze in interaction | Time-intensive, requires annotation |
| Wizard of Oz | Testing AI/robot behavior before implementation | User deception, ecological validity |
| Cultural probes | Understanding lived context at home/work | Subjective, hard to generalize |
| Experience sampling | Capturing in-situ experience over time | Interrupts natural flow |
| Co-design / participatory design | Getting user knowledge into design | Power dynamics, who is included |
| Speculative design / design fiction | Probing futures and values | Not predictive |
| A/B testing | Measuring behavior difference between variants | Quantitative, misses meaning and reason |
| Diary study | Long-term behavioral and experiential data | Compliance drops, self-selection bias |

---

## TANGIBLE INTERACTION SPECIFIC FRAMEWORKS

Relevant to the focus device project and robotics work:

### Tangible, Embedded, and Embodied Interaction (TEI)
- Physical objects that carry digital information or computation
- Key distinction: representational vs. action-based tangibles
- Representational: token on table represents digital object
- Action-based: physical action IS the computation (knob, lever, gesture)

### Physical Variables in Tangible Design
What physical properties carry meaning or trigger action?
- Shape, size, weight (ergonomic affordance)
- Surface texture (haptic feedback)
- Resistance / friction (effort as signal)
- Sound / vibration (ambient feedback)
- Temperature (rarely used, high expressivity)
- Spatial position and orientation (location as state)

### Feedforward vs. Feedback
- Feedback: information about what just happened
- Feedforward: information about what will happen if you do this
- Both matter. Tangible systems often excel at feedforward through physical affordance.

---

## HCI THEORY → DESIGN PROJECT BRIDGE

For any theory analyzed, ask these transfer questions:

**For the focus device (tangible + reward system):**
- What does this theory say about physical interaction creating psychological effect?
- Does the theory support or complicate the reward mechanism?
- What does embodied cognition say about interruption and re-engagement?

**For robotics / HRI (ArtInnov team):**
- What does this theory say about how humans form mental models of robot behavior?
- What interaction modalities does it suggest for human-robot collaboration?
- How does this apply when the robot is a peer vs. a tool vs. an agent?

**For AI + design research direction:**
- Where does human agency appear or disappear in this theory's account?
- What does this theory say about who or what is "doing the designing"?
- What are the ethical stakes this theory illuminates?

**For grad application portfolio:**
- Does engaging with this theory demonstrate a clear research identity?
- Can you articulate a gap or question this theory raises that you want to pursue?
- Which labs or advisors are working in the space this theory opens?

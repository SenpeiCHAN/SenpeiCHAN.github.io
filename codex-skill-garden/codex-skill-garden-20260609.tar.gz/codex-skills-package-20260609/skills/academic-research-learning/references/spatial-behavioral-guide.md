# Spatial & Behavioral Observation Guide

For architecture, urban studies, public space, and micro-space research.
Reference this when doing Stage 4 (Mechanism Reasoning) or Stage 5 (Reality Mapping) for spatially-oriented texts.

---

## SPATIAL ANALYSIS DIMENSIONS

### Scale and Proportion
- Human scale: 1–25m for personal interaction; 25–100m for social awareness; beyond 100m, anonymity
- Enclosure ratio: height-to-width ratios that create felt enclosure (H:W > 1 = enclosed, < 0.5 = open)
- Granularity: how many distinct spatial units does a 100m stretch contain?

### Boundary and Edge
- Hard edge: wall, fence, barrier — blocks movement and view
- Soft edge: threshold, setback, colonnade, planting — invites pause
- Gray space: the ambiguous zone between inside and outside (verandas, arcades, overhangs)
- Edge occupation: people preferentially occupy edges over open centers

### Visibility and Sightlines
- What can be seen from where?
- Prospect and refuge: people prefer positions with wide view AND back protection
- Surveillance capacity: can users see who is approaching?
- Visual depth: layers of view create felt richness

### Accessibility and Movement
- Multiple entry points vs. single entry
- Path hierarchy: primary path → secondary → pause zone
- Desire lines: informal paths that diverge from designed ones
- Permeability: how many ways through a space?

### Node and Path
- Node: a place where movement slows, gathers, or pauses
- Path: a route of movement with directionality
- Node activation: what physical features make people slow down or stop?

### Microclimate
- Sun angle by season and time of day
- Wind direction and shelter zones
- Shade radius from trees or overhangs
- Thermal comfort range: 17–25°C optimal for outdoor use

---

## BEHAVIORAL ANALYSIS DIMENSIONS

### Types of Activity (after Jan Gehl)
- Necessary activity: must happen regardless of environment (walking to work)
- Optional activity: happens only if conditions are good (sitting in sun, reading outside)
- Social activity: happens as a result of other people being present (conversation, people-watching)

Key insight [EXTERNAL — Gehl]: improve optional activity and social activity follows. Improve necessary activity conditions but expect less social yield.

### Duration of Stay
- Brief pause (0–2 min): person scanning or resting in transit
- Short stay (2–15 min): intentional use, often with a view or focal point
- Extended stay (15+ min): comfort, shelter, social activity, or work possible
- Duration correlates with: seating comfort, microclimate, activity diversity, social safety

### Positioning Behavior
- Edge preference: people sit at boundaries, not in open centers
- Back protection: chairs and benches against walls fill first
- Triangle effect: three people form a stable social group; two is asymmetric
- Distance norms: 0–45cm intimate / 45–120cm personal / 120–360cm social / 360cm+ public (Hall's proxemics [EXTERNAL])

### Avoidance Patterns
- Which areas go unused? Why?
- Avoidance predictors: no shelter from sun/wind, no back protection, dead-end without view, poor surveillance
- "Dead zones": areas with high foot traffic passing through but no pause activity

### Interaction Types
- Glance: brief visual acknowledgment
- Nod/smile: minimal social contact
- Verbal exchange: conversation between strangers
- Co-presence: being near others without direct interaction (still socially meaningful)
- Sustained interaction: conversation, shared activity

---

## OBSERVATION PROTOCOL

When conducting field observation, record:

### What to watch for
1. Where do people stop vs. pass through?
2. How long do they stay at each spot?
3. Where do groups form? What size?
4. Who interacts with whom? (age, group type)
5. What time of day and weather conditions?
6. Which edges are used? Which avoided?
7. How does microclimate affect use? (track sun and shade)
8. Are there repeated users (suggests place attachment)?
9. What activities occur? Necessary / optional / social?
10. What triggers interaction? (object, view, coincidence of paths)

### Recording methods
- Behavior mapping: mark positions and activities on a plan at intervals (10 or 15 min)
- Time-lapse counting: count users at fixed intervals
- Trace mapping: draw paths of movement on a base plan
- Interview spots: note where people stop long enough to be approached

---

## SPATIAL MECHANISM PATTERNS

Common spatial mechanisms relevant to public space and small plaza research:

### Edge Occupation Mechanism
Spatial condition: soft edge with back protection and forward view
→ Triggers prospect-refuge instinct
→ Person chooses edge over center
→ Extended duration possible
→ Social observation without social obligation
→ Optional activity becomes possible
→ If others present, social activity can follow

### Microclimate Activation Mechanism
Good microclimate (sun/shade in right ratio, wind shelter)
→ Physical comfort threshold met
→ Optional activity duration extends
→ Extended presence increases chance of encounter
→ Social activity increases
Failure condition: overheating, wind, rain with no shelter — optional activity collapses immediately

### Gray Space Invitation Mechanism
Spatial ambiguity (neither clearly inside nor outside)
→ Reduced social commitment required
→ Person can occupy without claiming
→ Allows watching without being watched
→ Enables gradual entry into social space
→ Lower threshold for first-time or hesitant users

### Node Formation Mechanism
Convergence of paths + reason to pause (view, vendor, seating, landmark)
→ Multiple users pause at same point
→ Co-presence occurs
→ Chance of social interaction increases
→ If interaction is positive, place identity forms
→ Repeated use more likely

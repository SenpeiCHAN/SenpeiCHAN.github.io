# Critical Thinking Toolkit

Use this when doing Stage 7 (Critical Analysis). 
These are structured thinking tools — not just checklists.

---

## TOOL 1 — ASSUMPTION MAPPING

Every theory rests on hidden assumptions. Surface them.

For each major claim in the text, ask:

**What must be true for this to hold?**

Example:
- Claim: "Active street edges generate social interaction"
- Hidden assumptions: 
  - People are predisposed to social contact in public
  - Physical environment is a primary driver of social behavior (not social norms, class, culture)
  - "Social interaction" is defined broadly enough to include glances and co-presence
  - The effect holds across cultures and climates

Then ask: **Are these assumptions stated? Examined? Or just assumed?**

---

## TOOL 2 — SCOPE ANALYSIS

A theory with no stated limits is a weak theory.

Ask:
1. **What is the stated scope?** (What does the author claim this applies to?)
2. **What is the actual scope?** (What does the evidence actually cover?)
3. **Where is the gap?** (What is claimed beyond what the evidence supports?)

Common scope problems:
- Studies done in one city generalized globally
- Studies of one demographic applied to all users
- Historical findings applied to contemporary conditions without reexamination
- Lab or survey findings applied to real spatial behavior

---

## TOOL 3 — FALSIFICATION TESTING

A good theory must be capable of being wrong.

For each major claim, construct:

**Falsifying condition:** *What real situation, if it existed and were documented, would show this theory is wrong?*

If you cannot construct a falsifying condition, the theory may be unfalsifiable — and that's a problem.

Example:
- Theory: "Human-scale streets generate more social activity"
- Falsifying condition: A human-scale street with low social activity despite meeting all design criteria, sustained over time, across different seasons and user groups
- Is such a case documented? If yes, how does the author respond?

---

## TOOL 4 — ARGUMENT GAP DETECTION

Find where the logic jumps.

Read each argument step by step and mark every place where:
- A claim is made without evidence
- A jump occurs between observation and conclusion
- Two things are correlated but causation is asserted
- An example is offered but treated as proof
- Opposing evidence is absent

Label gaps as:
- **[LEAP]** — argument jumps without warrant
- **[CORRELATION ≠ CAUSATION]** — cause assumed from association
- **[SINGLE CASE GENERALIZED]** — one example bears too much weight
- **[CHERRY-PICKED]** — only supportive evidence shown

---

## TOOL 5 — COUNTEREXAMPLE CONSTRUCTION

For every major theory, try to construct a genuine counterexample.

A counterexample is not just "this didn't work somewhere once."
A strong counterexample:
1. Meets the theory's stated conditions
2. Does not produce the predicted outcome
3. Is documented and replicable
4. Cannot be explained away by a minor adjustment

If you cannot construct a counterexample, the theory is stronger.
If you can, ask: **Does the author acknowledge this? What is their response?**

---

## TOOL 6 — CULTURAL AND HISTORICAL DISPLACEMENT

Ask two questions:

**1. When was this theory formed?**
- What historical conditions shaped the author's observations?
- Have those conditions changed?
- Would the theory predict the same things in a different era?

**2. Where was this theory formed?**
- What cultural, geographic, or political context shaped the observations?
- Does the theory travel across cultures?
- What would need to change for it to apply in a different cultural setting?

---

## TOOL 7 — THEORETICAL CONFLICT MAPPING

No theory exists alone. Identify theories that would push back.

For each major claim:
1. Name a theory that would predict differently
2. State what evidence would distinguish between them
3. Note whether the author acknowledges the competing theory

Common theoretical tensions in spatial and social research:
- Determinism (space shapes behavior) vs. Agency (people shape space)
- Structure (social forces determine patterns) vs. Practice (everyday acts constitute patterns)
- Universal human needs vs. Cultural specificity of behavior
- Quantitative patterns (space syntax, movement data) vs. Qualitative meaning (lived experience, phenomenology)

---

## TOOL 9 — HCI-SPECIFIC CRITICAL LENSES

When analyzing HCI, interaction design, or AI + design texts, add these checks:

**Participation problem:** Who was in the study? (WEIRD bias: Western, Educated, Industrialized, Rich, Democratic). Does the finding generalize beyond this population?

**Laboratory validity problem:** Was this studied in a lab or in real use context? Lab results often do not survive contact with messy real environments.

**Technology dependency problem:** Is the theory tied to a specific technology that no longer exists, or may soon not exist? (e.g., mouse-and-keyboard assumptions in older HCI work)

**Agency problem:** Does the system design give users meaningful agency, or just the appearance of control? Does the author question this?

**Values problem:** What values are embedded in the system or design described? Are they stated? Are they examined?

**Scale problem:** Does the finding hold for one user, ten users, a million users? Many HCI studies are small-scale and the theory is quietly extrapolated.

**Measurement problem:** What was measured, and what was not measured? Quantitative HCI studies often measure efficiency and error rates — but miss meaning, identity, and long-term adoption.

**AI-specific critical lens:** If the text involves AI systems — what is the system actually optimizing for? Who defined that objective? Who is excluded from the benefit? What happens when the system is wrong?


The hardest question: **Is this theory actually useful for the user's research?**

Do not answer "yes" automatically. Evaluate honestly:

1. **Direct applicability** — Does the theory describe the same object the user is studying?
2. **Mechanism relevance** — Does the mechanism the theory describes actually operate in the user's context?
3. **Evidence compatibility** — Can the user gather evidence that would confirm or complicate the theory in their specific case?
4. **Conceptual precision** — Is the theory precise enough to generate specific, testable claims in the user's research?
5. **Honest limitations** — What does this theory NOT help the user explain?

A theory that is "interesting but not directly applicable" is still valuable — it can sharpen thinking, provide contrast, or define what the user's research is NOT about.

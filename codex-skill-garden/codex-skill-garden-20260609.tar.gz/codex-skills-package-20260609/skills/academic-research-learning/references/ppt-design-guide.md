# PPT Design Guide — Cognitive Path Design

A PPT is not a layout of analysis. It is a **designed cognitive experience**.

Each slide answers one question and moves the audience one step forward in understanding.

---

## CORE PRINCIPLE: ONE SLIDE, ONE COGNITIVE TASK

Every slide must have a clear cognitive purpose:
- Raise a question that demands an answer
- Define a concept the audience needs to proceed
- Reveal a mechanism that explains why something happens
- Show a comparison that creates useful distinction
- Present a case that makes an abstract claim concrete
- Deliver a critique that adds intellectual honesty
- Transfer a theory into the user's specific research context
- Crystallize a framework the audience can carry away

If you cannot state in one sentence what cognitive task a slide performs, the slide is not ready.

---

## SLIDE STRUCTURES

### Opening / Title Slide
- State the core question of the presentation (not the title of the book)
- Subtitle: the position or answer you will argue toward
- No decoration beyond a clean visual

### Section Divider Slide
- Name the section
- State in one sentence what question this section will answer
- Show where this section sits in the overall argument flow

### Question Slide
Content:
- The question, large and clear
- Brief context (why this question matters, in 1–2 sentences)
- No answer yet — let the question breathe

Use when: opening a new section, introducing a theoretical problem, beginning a case study

### Concept Definition Slide
Content:
- Concept name
- Precise definition (from text, labeled [TEXT] or [EXPLAIN])
- What the concept is NOT (common misconceptions or neighboring terms)
- One brief example
- Optional: Feynman B sentence at bottom

Use when: introducing a term the audience needs to understand what follows

### Mechanism Slide
Content:
- Theory name and core claim (one sentence)
- Visual mechanism chain: A → B → C → D
- Brief explanation of each step (not full sentences — fragments or labels)
- Operating conditions (what must be true)
- One concrete case

This is the most important slide type. The mechanism chain must be visible and readable at a glance.

Use when: explaining how a theory works, not just what it claims

### Comparison Slide
Layout: two columns or two zones
Content:
- Left: Theory/concept/case A
- Right: Theory/concept/case B
- Bottom: What the comparison reveals (the insight)

Never make a comparison slide just to list differences. The comparison must produce a new insight.

Use when: two theories are in tension, two cases illuminate each other, two definitions compete

### Case Slide
Content:
- Case name and brief description
- The mechanism it illustrates (which theory, which chain)
- What is observable in the case (specific features)
- What the case confirms AND what it complicates
- Source label: [EXTERNAL] if not from the book

One case per slide. Do not stack cases — each deserves its own slide.

Use when: making an abstract claim concrete, showing a mechanism operating in reality

### Critique Slide
Content:
- The theoretical claim being evaluated
- Its assumption (what must be true)
- The limitation, gap, or counterexample
- The question it leaves open
- Optional: a competing theory that predicts differently

Do not soften critique into vague hedge. State it clearly.

Use when: intellectual honesty requires acknowledging what the theory cannot explain

### Transfer Slide
Content:
- The theoretical insight being transferred
- The user's specific research context
- The specific question this insight helps answer
- What evidence the user would need to gather

Use when: connecting reading to the user's own research project

### Summary / Knowledge Graph Slide
Content:
- A visual map of the key concepts and their relationships
- Not a word cloud — show the relationships with arrows and labels
- Can be built progressively across the presentation (reveal connections as they are established)

Use when: closing a section or the full presentation; building a map the audience can photograph and use

---

## SLIDE COUNT GUIDE

| Purpose | Slide Count | Notes |
|---------|-------------|-------|
| Quick classroom sharing | 12–20 | One mechanism, one case, one critique maximum |
| Standard book report | 25–40 | Full structure, 2–3 mechanisms, several cases |
| Research presentation | 40–70 | Full theory + knowledge graph + transfer |
| Full course deck | 70–120 | Complete book analysis with all stages |

Do not inflate slide count. 20 precise slides outperform 60 padded slides.

---

## VISUAL LANGUAGE

### Do:
- Clean white or off-white background
- High contrast typography
- Arrows and connectors to show relationships
- Diagrams built in the slide (not pasted images)
- Bold used only for one thing per slide (the core insight)
- Consistent grid and margin

### Do not:
- Long paragraphs (more than 3 lines of full text)
- Bullet lists that just restate analysis text
- Decorative images unrelated to content
- Multiple competing visual hierarchies on one slide
- Italics overused for emphasis
- Font size below 18pt for body, 24pt for headlines

---

## COGNITIVE PATH DESIGN

Before writing slides, map the cognitive path:

1. What does the audience know at the start?
2. What do they need to know to understand the core argument?
3. In what order should concepts be introduced? (No concept should appear before its prerequisites)
4. Where is the key insight? (This slide should be the most carefully designed)
5. What do you want them to remember and use after the presentation?

Design the slides to walk that path. Every slide serves the path. If a slide doesn't serve the path, cut it.

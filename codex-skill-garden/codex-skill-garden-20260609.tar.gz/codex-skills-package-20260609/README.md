# Codex Skills Package

This package contains the remaining personal Codex skills after duplicate cleanup.

## Install

On the target computer, copy all folders inside `skills/` into:

```bash
~/.codex/skills/
```

Example:

```bash
mkdir -p ~/.codex/skills
cp -R skills/* ~/.codex/skills/
```

Restart Codex after copying so the skills list refreshes.

## Removed As Duplicates

These local skills were removed from the active skills directory because they duplicate plugin-provided skills or a stronger local skill:

- `figma-code-connect-components`
- `figma-create-new-file`
- `figma-generate-design`
- `figma-generate-library`
- `figma-use`
- `writing-plans`

The removed folders were backed up on the source machine outside the active skills directory.
